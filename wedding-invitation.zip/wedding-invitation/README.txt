# Hajara & Abu Shamir — Wedding Invitation

This is a static, phone-first wedding invitation website.

## Deploy with the included GitHub Actions workflow

1. Upload `wedding-invitation.zip` to the root of your GitHub repository.
2. Create `.github/workflows/build.yml` and paste the workflow supplied separately.
3. In Settings → Pages, set Source to **GitHub Actions**.
4. Push/commit. The workflow extracts the ZIP and deploys its `index.html`.

Fonts are loaded from Google Fonts; the page otherwise has no build dependencies.
